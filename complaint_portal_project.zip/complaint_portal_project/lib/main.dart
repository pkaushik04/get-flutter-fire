import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Complaint Portal',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Complaint Portal',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20.0),
              Image.asset(
                'assets/12img.jpeg',
                height: 150, // Adjust the height as needed
              ),
              SizedBox(height: 20.0),
              LoginForm(),
              SizedBox(height: 20.0),
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RegisterPage()),
                  );
                },
                child: Text(
                  'Register',
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.blue,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginForm extends StatefulWidget {
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextField(
          controller: emailController,
          decoration: InputDecoration(
            labelText: 'Email',
          ),
        ),
        TextField(
          controller: passwordController,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Password',
          ),
        ),
        SizedBox(height: 20.0),
        ElevatedButton(
          onPressed: () {
            // Add authentication logic here
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ComplaintPortalPage()),
            );
          },
          child: Text('Login'),
        ),
      ],
    );
  }
}

class ComplaintPortalPage extends StatefulWidget {
  @override
  _ComplaintPortalPageState createState() => _ComplaintPortalPageState();
}

class _ComplaintPortalPageState extends State<ComplaintPortalPage> {
  List<Complaint> complaints = [];

  @override
  void initState() {
    super.initState();
    // Add dummy complaints for testing
    complaints.addAll([
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Complaint Portal'),
        backgroundColor: Colors.greenAccent,
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: CircleAvatar(
              backgroundImage: NetworkImage('https://example.com/your-image.jpg'), // replace with your image url
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: complaints.length,
        itemBuilder: (context, index) {
          return _buildComplaintListItem(complaints[index]);
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddComplaintPage,
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _buildComplaintListItem(Complaint complaint) {
  Color borderColor = _getBorderColor(complaint.difficulty);

  return GestureDetector(
    onTap: () {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(complaint.title),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  Text('Title: ${complaint.title}'),
                  Text('Body: ${complaint.body}'),
                ],
              ),
            ),
            actions: <Widget>[
              TextButton(
                child: Text('Close'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    },
    child: Container(
      margin: EdgeInsets.all(8.0),
      padding: EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        border: Border.all(color: borderColor, width: 2.0),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: ListTile(
        title: Text(complaint.title),
        subtitle: Text('Difficulty: ${complaint.difficulty.toString().split('.').last}'),
      ),
    ),
  );
}
  void _navigateToAddComplaintPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddComplaintPage(addComplaint: _addComplaint)),
    );
  }

  void _addComplaint(String title, String body, Difficulty selectedDifficulty) {
    setState(() {
      complaints.add(Complaint(title: title, body: body, difficulty: selectedDifficulty));
    });
  }

  Color _getBorderColor(Difficulty difficulty) {
    switch (difficulty) {
      case Difficulty.Easy:
        return Colors.green;
      case Difficulty.Medium:
        return Colors.yellow;
      case Difficulty.Hard:
        return Colors.red;
    }
  }
}
class AddComplaintPage extends StatefulWidget {
  final Function addComplaint;

  AddComplaintPage({required this.addComplaint});

  @override
  _AddComplaintPageState createState() => _AddComplaintPageState();
}
class _AddComplaintPageState extends State<AddComplaintPage> {
  TextEditingController titleController = TextEditingController();
  TextEditingController bodyController = TextEditingController();
  Difficulty selectedDifficulty = Difficulty.Easy;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Complaint'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Form(
          child: Column(
            children: [
              TextFormField(
                controller: titleController,
                decoration: InputDecoration(
                  labelText: 'Complaint Title',
                ),
              ),
              TextFormField(
                controller: bodyController,
                decoration: InputDecoration(
                  labelText: 'Complaint Body',
                ),
              ),
              DropdownButtonFormField<Difficulty>(
                value: selectedDifficulty,
                onChanged: (Difficulty? newValue) {
                  setState(() {
                    selectedDifficulty = newValue!;
                  });
                },
                items: <Difficulty>[
                  Difficulty.Easy,
                  Difficulty.Medium,
                  Difficulty.Hard,
                ].map<DropdownMenuItem<Difficulty>>((Difficulty value) {
                  return DropdownMenuItem<Difficulty>(
                    value: value,
                    child: Text(value.toString().split('.').last),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: 'Difficulty',
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  widget.addComplaint(titleController.text, bodyController.text, selectedDifficulty);
                  Navigator.pop(context);
                },
                child: Text('Add Complaint'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register'),
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Register',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20.0),
              RegisterForm(),
              SizedBox(height: 20.0),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text(
                  'Back to Login',
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.blue,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RegisterForm extends StatefulWidget {
  @override
  _RegisterFormState createState() => _RegisterFormState();
}

class _RegisterFormState extends State<RegisterForm> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextField(
          controller: emailController,
          decoration: InputDecoration(
            labelText: 'Email',
          ),
        ),
        TextField(
          controller: passwordController,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Password',
          ),
        ),
        SizedBox(height: 20.0),
        ElevatedButton(
          onPressed: () {
            // Add registration logic here
          },
          child: Text('Register'),
        ),
      ],
    );
  }
}

enum Difficulty {
  Easy,
  Medium,
  Hard,
}

class Complaint {
  final String title;
  final String body;
  final Difficulty difficulty;

  Complaint({required this.title, required this.body, required this.difficulty});
}
