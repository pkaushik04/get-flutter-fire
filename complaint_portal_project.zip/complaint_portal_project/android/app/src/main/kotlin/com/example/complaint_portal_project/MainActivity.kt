package com.example.complaint_portal_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
